// I denna fil läggs definitionerna (implementationen) av de funktioner
// som deklarerats i Time.h

#include "Time.h"
#include <iostream>
#include <string>

int main()
{
	Time t1{};
	Time t2{12, 40, 50};
	
	std::cout << t1.get_time_24_h() << "\n";
	std::cout << t2.get_time_24_h() << "\n";
	
	Time t3{};
	Time t4{12, 40, 50};
	
	std::cout << t3.get_time_am_pm() << "\n";
	std::cout << t4.get_time_am_pm() << "\n";
	return 0;
}
