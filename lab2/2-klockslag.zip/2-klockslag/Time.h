// Denna fil ska innehålla deklarationer för de typer och funktioner
// som behövs
#include <string>

class Time {
	private:
		int hours = 0;
		int minutes = 0;
		int seconds = 0;
		
	public:
		Time() {};
		
		Time(int h, int m, int s) {
			hours = h;
			minutes = m;
			seconds = s;
		};
		
		std::string get_time_24_h() {
			std::string time = "[" + std::to_string(hours) + ":" + std::to_string(minutes) + ":" + std::to_string(seconds) + "]";
			return time;
		}
		
		std::string get_time_am_pm() {
			if (hours <= 11) {
			std::string time = "[" + std::to_string(hours) + ":" + std::to_string(minutes) + ":" + std::to_string(seconds) + "]" + " am";
			return time;
			}
			else {
			std::string time = "[" + std::to_string(hours) + ":" + std::to_string(minutes) + ":" + std::to_string(seconds) + "]" + " pm";
			return time;
			}
		}
		
		//operation overload +
		Time operator + (int const n) const {
			return Time(int h, int m, int s + n)
		}
		
		//operation overload -
		//operation overload ++ (should work for both ++x and ++x)
		//operation overload -- (should work for both --x and --x)
		
		//operation overload <
		//operation overload >
		//operation overload ==
		//operation overload >= 
		//operation overload <= 
		//operation overload !=
};


//tider
//HH:MM:SS
//ska kunna skrivas som 24-timmarsklocka (23:00:00) och som am/pm (11:00:00 PM)
//output ska vara en sträng (string)
//inmatning sker som HH:MM:SS
//ska kunna felhanteras (e.g. minut = 73) med flaggan fail


